import csv
import pandas as pd 
import ipaddress
import re
from datetime import datetime

def remove_periods_from_csv(csv_file, column_name):
    # Read the CSV file using pandas
    df = pd.read_csv(csv_file)

    # Remove periods from the specified column
    df[column_name] = df[column_name].str.replace(".", "")

    # Save the modified DataFrame back to CSV
    df.to_csv(csv_file, index=False, quoting=csv.QUOTE_ALL)

    print("Periods removed from the CSV file.")

#remove_periods_from_csv('../../traces/zeek/zat/conn.csv', 'id.resp_h')

def delete_rows_with_colon(csv_file, column_name):
    # Read the CSV file
    with open(csv_file, 'r') as file:
        reader = csv.DictReader(file)
        rows = [row for row in reader if ":" not in row[column_name]]

    # Write the filtered rows back to a new CSV file
    with open(csv_file, 'w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=reader.fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print("Rows containing a colon in the specified column have been deleted.")

#csv_file = "../../traces/zeek/raw.csv"
#column_name = "dstip"
#delete_rows_with_colon(csv_file, column_name)

def convert_ts():
    # Open the input CSV file
    with open('../../traces/zeek/zat/conn.csv', 'r') as file:
        reader = csv.reader(file)
        rows = list(reader)

    # Modify the desired column (e.g., column index 2)
    for row in rows[1:]:
        data_string = row[0]
        date_string_truncated = row[0][:230]  # Truncate the microseconds to two decimal places
        datetime_obj = datetime.strptime(date_string_truncated, '%Y-%m-%d %H:%M:%S.%f')
        formatted_date = datetime_obj.strftime('%Y%m%d%H%M%S.%f')[:-1]
        row[0] = formatted_date


    # Write the modified data to a new CSV file
    with open('../../traces/zeek/zat/raw.csv', 'w', newline='') as file:

        writer = csv.writer(file)
        writer.writerows(rows)


#convert_ts()
import pandas as pd

# Read the CSV file into a pandas DataFrame
df = pd.read_csv('../../traces/zeek/zat/conn.csv')

# Convert the column to datetime format
df['ts'] = pd.to_datetime(df['ts'])

# Extract the desired information
df['ts'] = df['ts'].dt.strftime('%d%H%M%S%f')

# Save the updated DataFrame to a new CSV file
df.to_csv('../../traces/zeek/zat/raw.csv', index=False)


